# TopoPraxis (Spatial logic)
Purpose: regions, adjacency, and spatial reasoning.
Status: v0.1 scaffold, zero admits.
