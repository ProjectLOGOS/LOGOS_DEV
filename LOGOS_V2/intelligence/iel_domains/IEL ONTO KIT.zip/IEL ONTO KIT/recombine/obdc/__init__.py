# OBDC - Object-Based Denotational Calculus kernel
