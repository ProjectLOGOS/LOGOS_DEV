# CosmoPraxis (Cosmology: Chrono + Topo)
Purpose: unify temporal modes (ChronoPraxis) with spatial structure (TopoPraxis).
Status: v0.1 scaffold, zero admits.
